﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odev_1
{
    class Takim
    {
        Asker[] birlik = new Asker[7];
        

        public Asker[] Birlik { get { return birlik; } set { birlik = value; } }

        // ..... //
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odev_1
{
    class Tegmen : Asker
    {
        // Fonksiyonları meydan üzerinde çalışabilecek şekilde yaratamadığım için bu şekilde bıraktım //
        public override void Ates_Et()
        {
            throw new NotImplementedException();
        }

        public override void Bekle()
        {
            throw new NotImplementedException();
        }

        public override void HaraketEt()
        {
            throw new NotImplementedException();
        }
    }
}

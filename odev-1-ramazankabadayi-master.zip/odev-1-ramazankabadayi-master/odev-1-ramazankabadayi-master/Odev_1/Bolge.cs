﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odev_1
{
    public class Bolge
    {
        // ..... //
        public Bolge()
        {

        }

        public Asker BolgedekiAsker { get; set; }

    }
}
